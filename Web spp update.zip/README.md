# Sistem Pembayaran SPP MA Plus Taruna Teknik Al Jabbar

Aplikasi web pembayaran SPP berbasis Laravel untuk membantu pengelolaan tagihan, pembayaran, tunggakan, laporan, dan monitoring pembayaran siswa di MA Plus Taruna Teknik Al Jabbar.

Judul TA:

**Implementasi Algoritma Sequential Search pada Pembayaran SPP Berbasis Web di MA Plus Taruna Teknik Al Jabbar**

## Ringkasan

Sistem ini menyediakan portal pembayaran SPP dengan beberapa role pengguna:

- **Admin TU** untuk mengelola data master, siswa, tagihan, pembayaran, tunggakan, laporan, notifikasi, dan akun pengguna.
- **Siswa/Orang Tua** untuk melihat tagihan, membayar SPP, melihat riwayat pembayaran, dan mengunduh kwitansi.
- **Wali Kelas** untuk memantau siswa, tagihan, pembayaran, tunggakan, laporan kelas, dan kontak orang tua berdasarkan kelas yang diampu.
- **Kepala Sekolah** untuk monitoring laporan bulanan, laporan kelas, grafik pemasukan, dan cetak laporan PDF secara read-only.

## Fitur Utama

- Login multi-role dengan pembatasan akses berdasarkan role.
- Redirect otomatis ke dashboard jika user yang sudah login membuka halaman login.
- Dashboard ringkasan sesuai role pengguna.
- Pengelolaan data siswa, kelas, tahun ajaran, dan biaya SPP.
- Import dan export data siswa menggunakan Excel.
- Generate tagihan bulanan berdasarkan tahun ajaran, kelas, dan biaya SPP.
- Pengaturan jadwal tagihan otomatis.
- Fitur gratis atau diskon tagihan untuk siswa, kelas, atau semua siswa.
- Pengelolaan tunggakan siswa dan konfirmasi pembayaran dari daftar tunggakan.
- Pembayaran tunai melalui antrian konfirmasi Admin TU.
- Pembayaran manual oleh Admin TU.
- Pembayaran online melalui Midtrans Snap.
- Webhook Midtrans dengan verifikasi signature key.
- Pembersihan pembayaran Midtrans pending yang sudah kedaluwarsa.
- Riwayat transaksi dan invoice/kwitansi pembayaran.
- Export laporan pembayaran ke PDF dan Excel.
- Notifikasi web untuk status pembayaran dan informasi sistem.
- Tombol WhatsApp berbasis `wa.me` untuk menghubungi orang tua siswa.
- Pencarian Sequential Search pada data siswa, transaksi pembayaran, dan laporan.

## Teknologi

- PHP 8.2+
- Laravel 11
- MySQL/MariaDB
- Bootstrap 5
- Vite
- Midtrans PHP SDK
- DomPDF
- Laravel Excel

## Struktur Menu

### Admin TU

- Dashboard
- Pengaturan SPP
- Data Siswa
- Tunggakan Siswa
- Antrian Pembayaran Tunai
- Transaksi Pembayaran
- Pencarian Sequential
- Laporan
- Manajemen User

### Siswa/Orang Tua

- Dashboard
- Tagihan Saya
- Riwayat Pembayaran
- Profil Siswa

### Wali Kelas

- Dashboard Kelas
- Data Siswa Kelas
- Tagihan Kelas
- Pembayaran Kelas
- Tunggakan Kelas
- Laporan Kelas
- Kontak Orang Tua

### Kepala Sekolah

- Dashboard
- Laporan Bulanan
- Laporan Kelas
- Grafik Pemasukan
- Cetak PDF laporan

## Akun Demo

Setelah menjalankan seeder, akun demo yang tersedia:

| Role | Username | Password |
| --- | --- | --- |
| Admin TU | `admin` | `password` |
| Kepala Sekolah | `kepala` | `password` |
| Wali Kelas | `wali` | `password` |
| Siswa | `26260001` | `password` |

Username siswa menggunakan NIS dari data seed. Contoh lain mengikuti format `26260002`, `26260003`, dan seterusnya.

Akun wali kelas demo terhubung ke kelas X-A. Akun wali kelas lain dapat dibuat melalui menu **Admin TU > Manajemen User** dan dihubungkan ke kelas tertentu.

## Instalasi

Panduan detail untuk Windows dan Laragon tersedia di [`INSTALL.md`](INSTALL.md).

### 1. Clone atau salin project

Masuk ke folder project:

```bash
cd nama-folder-project
```

### 2. Install dependency PHP

```bash
composer install
```

### 3. Install dependency frontend

```bash
npm install
```

### 4. Siapkan file environment

Salin file `.env.example` menjadi `.env`, lalu sesuaikan konfigurasi database dan Midtrans.

```bash
cp .env.example .env
```

Jika menggunakan Windows Command Prompt:

```bat
copy .env.example .env
```

Generate application key:

```bash
php artisan key:generate
```

Perintah ini wajib dijalankan di komputer baru karena `APP_KEY` pada `.env.example` memang sengaja dikosongkan.

### 5. Buat database

Buat database MySQL/MariaDB:

```sql
CREATE DATABASE spp_al_jabbar;
```

Contoh konfigurasi `.env`:

```env
APP_NAME="SPP Al Jabbar"
APP_ENV=local
APP_DEBUG=true
APP_URL=http://127.0.0.1:8000

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=spp_al_jabbar
DB_USERNAME=root
DB_PASSWORD=

MIDTRANS_SERVER_KEY=SB-Mid-server-CHANGE_ME
MIDTRANS_CLIENT_KEY=SB-Mid-client-CHANGE_ME
MIDTRANS_IS_PRODUCTION=false

QUEUE_CONNECTION=database
```

### 6. Migrasi dan seed data

```bash
php artisan migrate --seed
```

Sebelum demo di komputer lain, disarankan mencoba instalasi dari nol:

```bash
php artisan migrate:fresh --seed
```

Perintah ini memastikan urutan migration berjalan benar, termasuk status tagihan `gratis` yang ditambahkan oleh migration fitur tagihan otomatis. Jangan gunakan `migrate:fresh` pada database produksi karena semua data lama akan dihapus.

### 7. Jalankan aplikasi

```bash
php artisan serve
```

Buka aplikasi di browser:

```text
http://127.0.0.1:8000
```

Untuk mode development frontend:

```bash
npm run dev
```

Untuk build asset production:

```bash
npm run build
```

## Konfigurasi Midtrans

Sistem menggunakan Midtrans Snap untuk pembayaran online.

Konfigurasi yang perlu diatur di `.env`:

```env
MIDTRANS_SERVER_KEY=SB-Mid-server-CHANGE_ME
MIDTRANS_CLIENT_KEY=SB-Mid-client-CHANGE_ME
MIDTRANS_IS_PRODUCTION=false
```

Untuk sandbox, gunakan key dari dashboard Midtrans sandbox dan isi `MIDTRANS_IS_PRODUCTION=false`.

Webhook pembayaran tersedia di:

```text
/midtrans/webhook
```

Jika aplikasi dijalankan di lokal dan ingin menerima webhook dari Midtrans, gunakan tunnel seperti Ngrok, lalu daftarkan URL webhook di dashboard Midtrans.

## Scheduler dan Tagihan Otomatis

Project memiliki scheduler untuk:

- menjalankan generate tagihan bulanan otomatis,
- membersihkan pembayaran Midtrans pending yang sudah kedaluwarsa.

Command generate tagihan bulanan:

```bash
php artisan tagihan:generate-bulanan
```

Untuk menjalankan scheduler Laravel:

```bash
php artisan schedule:work
```

Jika `QUEUE_CONNECTION=database`, jalankan queue worker saat demo agar job antrian diproses:

```bash
php artisan queue:work
```

Untuk demo lokal yang sederhana, `QUEUE_CONNECTION` juga bisa diubah menjadi `sync` supaya job langsung dieksekusi tanpa worker terpisah. Di production, scheduler sebaiknya dijalankan melalui cron/server task.

## Alur Pembayaran

### Pembayaran Online

1. Login sebagai siswa.
2. Buka menu **Tagihan Saya**.
3. Pilih tagihan yang belum lunas.
4. Klik **Bayar Online**.
5. Sistem membuat transaksi dan membuka pembayaran Midtrans Snap.
6. Setelah pembayaran berhasil, webhook Midtrans memperbarui status pembayaran dan tagihan.
7. Kwitansi dapat dilihat melalui menu **Riwayat Pembayaran**.

### Pembayaran Tunai

1. Login sebagai siswa.
2. Buka menu **Tagihan Saya**.
3. Pilih **Bayar Tunai**.
4. Sistem membuat antrian pembayaran tunai.
5. Login sebagai Admin TU.
6. Buka menu **Antrian Pembayaran Tunai**.
7. Konfirmasi pembayaran jika uang sudah diterima.
8. Status tagihan berubah menjadi lunas dan kwitansi tersedia.

### Pembayaran Manual Admin

1. Login sebagai Admin TU.
2. Buka menu **Transaksi Pembayaran**.
3. Pilih tagihan belum lunas.
4. Input pembayaran manual.
5. Sistem mencatat transaksi sebagai pembayaran sukses.

## Laporan

Admin TU dapat membuat dan mengunduh laporan dalam format:

- PDF
- Excel

Kepala Sekolah dapat melihat laporan monitoring dan mencetak PDF, tetapi tidak memiliki akses untuk mengubah data pembayaran.

## Sequential Search

Implementasi algoritma Sequential Search berada di:

```text
app/Services/SequentialSearchService.php
```

Sequential Search digunakan untuk mencari data dengan cara memeriksa item satu per satu dari awal sampai akhir.

Menu yang menggunakan Sequential Search:

- **Admin TU > Data Siswa**
- **Admin TU > Transaksi Pembayaran**
- **Admin TU > Pencarian Sequential**
- **Admin TU > Laporan**
- **Kepala Sekolah > Laporan Bulanan**

Informasi yang ditampilkan pada hasil pencarian:

- jumlah data yang diperiksa,
- durasi pencarian dalam milidetik,
- hasil data yang cocok.

Catatan TA:

Controller mengambil data menggunakan Eloquent, lalu proses pencarian utama dilakukan oleh `SequentialSearchService` melalui looping data collection. Dengan begitu, proses pencarian nama/NIS dapat dijelaskan sebagai penerapan Sequential Search.

## File dan Folder Penting

```text
app/                  Logic aplikasi, controller, model, service, middleware
bootstrap/            Bootstrap aplikasi Laravel
config/               Konfigurasi aplikasi
database/             Migration dan seeder
public/               Entry point aplikasi dan asset publik
resources/views/      Template Blade
routes/               Definisi route web dan console
storage/              Log, cache, dan file runtime
composer.json         Dependency PHP
package.json          Dependency frontend
INSTALL.md            Panduan instalasi lengkap
```

Folder berikut tidak perlu dikirim sebagai source code karena bisa dibuat ulang:

```text
vendor/
node_modules/
storage/framework/views/
storage/logs/
bootstrap/cache/
```

File `.env` berisi konfigurasi sensitif dan tidak disarankan dibagikan ke publik. Gunakan `.env.example` sebagai template konfigurasi.

## Catatan Deployment

Untuk server production:

- set `APP_ENV=production`,
- set `APP_DEBUG=false`,
- gunakan key Midtrans production jika sudah live,
- jalankan `composer install --no-dev --optimize-autoloader`,
- jalankan `npm run build`,
- pastikan document root server mengarah ke folder `public`,
- jalankan migrasi database,
- aktifkan scheduler Laravel,
- pastikan permission folder `storage` dan `bootstrap/cache` sesuai.

## Lisensi

Project ini dibuat untuk kebutuhan tugas akhir dan implementasi sistem pembayaran SPP MA Plus Taruna Teknik Al Jabbar.
