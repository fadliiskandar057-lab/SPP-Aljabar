<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pembayaran extends Model
{
    protected $table = 'pembayaran';
    protected $fillable = [
        'tagihan_id', 'siswa_id', 'kode_invoice', 'metode', 'nominal', 'status',
        'midtrans_order_id', 'midtrans_transaction_id', 'paid_at', 'verified_by', 'bukti_path',
    ];

    protected function casts(): array
    {
        return ['paid_at' => 'datetime'];
    }

    public function tagihan()
    {
        return $this->belongsTo(Tagihan::class);
    }

    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    public function verifier()
    {
        return $this->belongsTo(User::class, 'verified_by');
    }
}
